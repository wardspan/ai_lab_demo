/// <reference types="vite/client" />

declare const __APP_VERSION__: string;
declare const __API_BASE__: string;
